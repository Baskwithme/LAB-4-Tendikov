function ProductCard({ product, onAdd, featured }) {
  return (
    <article className={featured ? 'card card--featured' : 'card'}>
      {featured && <span className="badge">Товар недели</span>}
      {product.image && <img src={product.image} alt={product.name} />}
      <h3>{product.name}</h3>
      {product.category && <p className="card-category">{product.category}</p>}
      <p className="card-price">{product.price} тг</p>
      <button type="button" onClick={() => onAdd(product)}>В корзину</button>
    </article>
  );
}

export default ProductCard;
